package com.example.bandaab.SplitwiseTest.Presenter.Search;

/**
 * Created by bandaab on 1/13/18.
 */

public interface ISearchPresenter {
    void attemptSearch(String searchText);
}
