package com.example.bandaab.SplitwiseTest.UI.activities;

import android.os.Bundle;

import com.example.bandaab.SplitwiseTest.UI.BaseActivity;
import com.example.bandaab.modelviewprespractice.R;

public class SearchActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_activity);
    }
}
