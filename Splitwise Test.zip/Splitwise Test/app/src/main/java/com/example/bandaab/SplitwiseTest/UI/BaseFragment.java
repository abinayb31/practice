package com.example.bandaab.SplitwiseTest.UI;

import android.app.Fragment;

/**
 * Created by bandaab on 1/14/18.
 */

public class BaseFragment extends Fragment {
}
