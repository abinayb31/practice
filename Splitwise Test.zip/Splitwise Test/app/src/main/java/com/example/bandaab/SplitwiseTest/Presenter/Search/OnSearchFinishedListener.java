package com.example.bandaab.SplitwiseTest.Presenter.Search;

/**
 * Created by jpotts18 on 5/11/15.
 */
public interface OnSearchFinishedListener {
    void onError();
    void onSuccess();
}
