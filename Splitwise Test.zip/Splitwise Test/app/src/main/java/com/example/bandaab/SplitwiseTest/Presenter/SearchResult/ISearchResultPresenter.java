package com.example.bandaab.SplitwiseTest.Presenter.SearchResult;

import android.widget.ImageView;

/**
 * Created by bandaab on 1/14/18.
 */

public interface ISearchResultPresenter {
    void onImageDownload(ImageView imageView, String url);
}
