package com.example.bandaab.SplitwiseTest.UI.activities;

import android.os.Bundle;

import com.example.bandaab.modelviewprespractice.R;
import com.example.bandaab.SplitwiseTest.UI.BaseActivity;

/**
 * Created by bandaab on 1/14/18.
 */

public class SearchResultActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_result_activity);
    }
}
