package com.example.bandaab.SplitwiseTest.UI;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by bandaab on 1/14/18.
 */

public class BaseActivity  extends AppCompatActivity {
}
