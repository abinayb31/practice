package com.example.bandaab.SplitwiseTest.util;

/**
 * Created by bandaab on 1/14/18.
 */

public class Constants {

    public static final String SEARCH_RESULT_RESPONSE = "SEARCH_RESULT_RESPONSE";
}
