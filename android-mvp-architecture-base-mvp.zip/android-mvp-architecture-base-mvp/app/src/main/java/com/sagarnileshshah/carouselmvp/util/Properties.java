package com.sagarnileshshah.carouselmvp.util;

public class Properties {

    public static final String BUNDLE_KEY_PHOTO = "BUNDLE_KEY_PHOTO";
    public static final String PHOTO_URL = "https://farm%s.staticflickr.com/%s/%s_%s_z.jpg";

}
