package com.mc10.bandaab.mc10codingassignment.Presenter.Login;

/**
 * Created by bandaab on 1/13/18.
 */

public interface ILoginPresenter {
    void attemptLogin(String email, String password);
}
