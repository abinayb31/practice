package com.mc10.bandaab.mc10codingassignment.UI;


import android.app.Fragment;

/**
 * Created by bandaab on 1/16/18.
 */

public class BaseFragment extends Fragment{
}
