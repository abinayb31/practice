package com.mc10.bandaab.mc10codingassignment.UI.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.mc10.bandaab.mc10codingassignment.R;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);
    }
}
