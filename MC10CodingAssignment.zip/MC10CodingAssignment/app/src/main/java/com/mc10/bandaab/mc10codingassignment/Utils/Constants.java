package com.mc10.bandaab.mc10codingassignment.Utils;

/**
 * Created by bandaab on 1/16/18.
 */

public class Constants {
    public static final String LOGIN_RESULT_RESPONSE = "LOGIN_RESULT_RESPONSE";
    public static final String STUDY_RESULT_RESPONSE = "STUDY_RESULT_RESPONSE";
}
