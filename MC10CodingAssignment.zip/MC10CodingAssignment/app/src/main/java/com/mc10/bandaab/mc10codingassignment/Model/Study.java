package com.mc10.bandaab.mc10codingassignment.Model;

import java.io.Serializable;

/**
 * Created by bandaab on 1/16/18.
 */

public class Study implements Serializable{
    private String[] tags;

    private String[] programs;

    private String accountId;

    private String[] flags;

    private String createdTs;

    private String[] subjects;

    private String[] deviceConfigs;

    private String isArchived;

    private String lifecycleState;

    private String[] pipelines;

    private String id;

    private String title;

    private String[] diaries;

    private String[] activities;

    private String displayName;

    public String[] getTags ()
    {
        return tags;
    }

    public void setTags (String[] tags)
    {
        this.tags = tags;
    }

    public String[] getPrograms ()
    {
        return programs;
    }

    public void setPrograms (String[] programs)
    {
        this.programs = programs;
    }

    public String getAccountId ()
    {
        return accountId;
    }

    public void setAccountId (String accountId)
    {
        this.accountId = accountId;
    }

    public String[] getFlags ()
    {
        return flags;
    }

    public void setFlags (String[] flags)
    {
        this.flags = flags;
    }

    public String getCreatedTs ()
    {
        return createdTs;
    }

    public void setCreatedTs (String createdTs)
    {
        this.createdTs = createdTs;
    }

    public String[] getSubjects ()
    {
        return subjects;
    }

    public void setSubjects (String[] subjects)
    {
        this.subjects = subjects;
    }

    public String[] getDeviceConfigs ()
    {
        return deviceConfigs;
    }

    public void setDeviceConfigs (String[] deviceConfigs)
    {
        this.deviceConfigs = deviceConfigs;
    }

    public String getIsArchived ()
    {
        return isArchived;
    }

    public void setIsArchived (String isArchived)
    {
        this.isArchived = isArchived;
    }

    public String getLifecycleState ()
    {
        return lifecycleState;
    }

    public void setLifecycleState (String lifecycleState)
    {
        this.lifecycleState = lifecycleState;
    }

    public String[] getPipelines ()
    {
        return pipelines;
    }

    public void setPipelines (String[] pipelines)
    {
        this.pipelines = pipelines;
    }

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String getTitle ()
    {
        return title;
    }

    public void setTitle (String title)
    {
        this.title = title;
    }

    public String[] getDiaries ()
    {
        return diaries;
    }

    public void setDiaries (String[] diaries)
    {
        this.diaries = diaries;
    }

    public String[] getActivities ()
    {
        return activities;
    }

    public void setActivities (String[] activities)
    {
        this.activities = activities;
    }

    public String getDisplayName ()
    {
        return displayName;
    }

    public void setDisplayName (String displayName)
    {
        this.displayName = displayName;
    }
}

