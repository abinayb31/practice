package com.mc10.bandaab.mc10codingassignment.Presenter.Splash;

/**
 * Created by bandaab on 1/16/18.
 */

public interface IBluetoothValidator {
    void checkBluetooth(ICheckBluetoothConnectionListener bluetoothConnectionListener);
}
