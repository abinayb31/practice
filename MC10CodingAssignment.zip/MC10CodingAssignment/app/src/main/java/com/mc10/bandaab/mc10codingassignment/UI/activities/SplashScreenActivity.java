package com.mc10.bandaab.mc10codingassignment.UI.activities;

import android.os.Bundle;

import com.mc10.bandaab.mc10codingassignment.R;
import com.mc10.bandaab.mc10codingassignment.UI.BaseActivity;

/**
 * Created by bandaab on 1/16/18.
 */

public class SplashScreenActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_activity);
    }

}
